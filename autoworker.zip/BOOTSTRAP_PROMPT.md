# Bootstrap prompt

Paste the block below into a fresh Claude Code session opened in your target
repo. Claude will fetch this template repo, ask you for the per-project
parameters, render the templates into your repo, create the tracker issue,
and open a PR you can review + merge.

The bootstrap is a one-time operation per target repo. After it's done,
day-to-day operation uses the [`LOOP_PROMPT`](LOOP_PROMPT.md).

---

```
You are installing the Claude Monitor + Autopilot pattern into THIS repo.
The template repo lives at https://github.com/mbansia/AutoWorker.

Steps:

1. Fetch the template content. Read the README, SETUP.md, LOOP_PROMPT.md,
   and every file under templates/.

2. Ask me (the operator) for exactly these parameters using the
   AskUserQuestion tool, ONE at a time, with sensible defaults proposed:

   - PROJECT_NAME (display name, e.g. "AutoTrader Codex")
   - REPO_SLUG (owner/name, autodetected from `git remote -v` if possible)
   - SSOT_PATH (the spec doc, default: docs/SYSTEM.md; if no doc exists,
     suggest creating one with a minimal §1/§3/§8/§11/§16 skeleton)
   - DIAGNOSTICS_ENDPOINT (e.g. /api/diagnostics; default skip if the
     project has no HTTP surface — pattern still works with manual
     health checks)
   - CRON_CADENCE (default: '0 */3 * * *')
   - INSTALL_TRACKER_CRON (Y/N; if Y you'll wire up two GitHub secrets:
     BOT_URL + DIAGNOSTICS_TOKEN; if N the loop runs via /loop only and
     uses no cron)

3. Render the templates with those parameters into the target repo:
     templates/MONITOR_RUNBOOK.md   → MONITOR_RUNBOOK.md
     templates/UPGRADE_BACKLOG.md   → UPGRADE_BACKLOG.md
     templates/CLAUDE.md.snippet    → merge into CLAUDE.md (create if absent)
     templates/diagnostics.yml      → .github/workflows/diagnostics.yml
                                       (only if INSTALL_TRACKER_CRON=Y)
     templates/diagnostics_post.py  → .github/scripts/diagnostics_post.py
                                       (only if INSTALL_TRACKER_CRON=Y)

   Substitute {{PROJECT_NAME}}, {{REPO_SLUG}}, {{SSOT_PATH}},
   {{DIAGNOSTICS_ENDPOINT}}, {{CRON_CADENCE}}, {{TRACKER_ISSUE_NUMBER}}
   throughout. TRACKER_ISSUE_NUMBER will be known after step 4.

4. Create the tracker issue via mcp__github__issue_write:
       title: "[bot-diagnostics] Tracker"
       labels: ["bot-diagnostics"]
       body: a one-line placeholder ("Initial — awaiting first cron run.")
   Record its issue number. Substitute back into the rendered runbook.

5. Open a PR (branch claude/install-monitor-autopilot) with everything
   from step 3. Title: "Install Claude Monitor + Autopilot pattern".
   Body: a short summary + a list of operator next-steps (set secrets,
   define the never-autoship list in the runbook's policy section,
   first /loop invocation).

6. Output the LOOP_PROMPT verbatim so the operator can copy it for
   their /loop invocation.

Constraints:
- Do NOT install anything that touches the operator's strategy / business
  logic. Only the monitor + autopilot pattern files.
- Do NOT push directly to main. PR only.
- If the target repo has no SSOT doc and no CLAUDE.md, OFFER to scaffold
  a minimal one but ASK before creating.
- If the target is a money-handling service and there's no clear policy
  section ("never autoship" boundary), STOP and tell the operator to
  define it first. Autopilot without a policy boundary is unsafe.
```
