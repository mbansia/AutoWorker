# Claude Monitor + Autopilot

A reusable pattern for delegating routine monitoring and bounded code-shipping
to Claude Code sessions, with hard policy guardrails. Born from operating a
production trading bot ([`AutoTrader_Codex`](https://github.com/mbansia/autotrader_codex))
under continuous Claude supervision.

**What it does:**

- A **monitor** session reads a persistent tracker issue every cron cycle,
  classifies anomalies against your spec, and either comments, opens a PR,
  or asks you — per a rule set you control.
- An **autopilot** session (same loop, second half of each pass) ships
  small, focused PRs from defined safe surfaces: bug fixes, test coverage,
  doc drift, your hint backlog. It NEVER touches policy (math, schema,
  contracts, credentials).
- Both run via Claude Code's `/loop` skill, an external SDK cron, or
  manual invocation — your choice.

**What it gives you:**

- One operator-curated spec (your SSOT) is the binding source of truth.
- A persistent GitHub tracker issue is the source of recent activity.
- A runbook tells Claude how to read both and what to do.
- Hard "never autoship" list — operator-defined boundary the loop cannot
  cross.
- Backpressure rails: one PR per pass, CI-green required, un-reviewed PRs
  pause shipping, operator pushback triggers a cooldown.

## When to use this

- You run a long-running service (bot, scraper, scheduler) and want hands-off
  monitoring + drift correction.
- You already have a `/health` or `/api/diagnostics` style endpoint, OR
  you can stand one up.
- You have a spec doc (or are willing to write one) that defines what
  "healthy" means and what "policy" means.

## When NOT to use this

- The service handles real money and you have no spec doc yet. **Write the
  spec first.** The autopilot relies on it as the immutable boundary.
- You want fully unsupervised behaviour without any guardrails. This
  pattern is bounded autonomy, not full autonomy.
- The service has no observable health surface. Build that first.

## Repo layout

```
README.md              # this file
SETUP.md               # how to install into your target repo
BOOTSTRAP_PROMPT.md    # paste this into a fresh Claude Code session
LOOP_PROMPT.md         # the /loop prompt
EXAMPLE_AUTOTRADER.md  # case study: how it's wired in AutoTrader_Codex
LICENSE                # MIT
templates/
  MONITOR_RUNBOOK.md
  UPGRADE_BACKLOG.md
  CLAUDE.md.snippet
  diagnostics.yml      # optional cron workflow
  diagnostics_post.py  # optional cron tracker updater
```

## Fast install

In a Claude Code session in your target repo, paste [`BOOTSTRAP_PROMPT.md`](BOOTSTRAP_PROMPT.md).
The session asks for ~5 parameters, renders the templates, creates the
tracker issue, opens a PR.

Manual install: read [`SETUP.md`](SETUP.md).

## Acknowledgements

Pattern + safety rails developed during the v1.3 → v1.5 rewrite of
[AutoTrader_Codex](https://github.com/mbansia/autotrader_codex). See
[`EXAMPLE_AUTOTRADER.md`](EXAMPLE_AUTOTRADER.md) for a concrete deployment.

## License

MIT.
