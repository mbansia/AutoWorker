# Example deployment: AutoTrader_Codex

The pattern in action. [`mbansia/autotrader_codex`](https://github.com/mbansia/autotrader_codex)
is a Python / FastAPI funding-rate arbitrage bot — three venues (Binance,
KuCoin, Hyperliquid), SQLite, single-instance, real money. It runs under
continuous Claude supervision via the monitor + autopilot loop documented
here.

## Parameter values

| Parameter | Value |
|---|---|
| PROJECT_NAME | AutoTrader_Codex |
| REPO_SLUG | mbansia/autotrader_codex |
| SSOT_PATH | docs/SYSTEM.md |
| DIAGNOSTICS_ENDPOINT | /api/diagnostics |
| CRON_CADENCE | `0 */3 * * *` (every 3 hours) |
| TRACKER_ISSUE_NUMBER | 28 |

## SSOT shape

`docs/SYSTEM.md` is ~1900 lines. The sections the loop relies on:

- **§0 Definitions** — vocabulary
- **§3.1 SOP + math** — system behaviour
- **§4 Configuration** — runtime knobs (in the never-autoship list)
- **§7.1.1 Frozen schema** — additive-only migration policy
- **§8.1 Frozen JSON contract** — `/api/diagnostics` shape
- **§8.2 Anomaly rules** — what each anomaly means
- **§9 Rejection categories** — what's normal vs regression
- **§10 Failure modes**
- **§11 Response policy** — the action matrix
- **§13 Doc-update policy** — binding
- **§16 Learnings** — append-only regression catalogue
- **§18 Open implementation gaps** — Tier C is autopilot-eligible

If your project has nothing like this, the pattern probably needs a spec
doc written first. The bot's spec was written *before* the rewrite started;
the loop runs against the doc, not against vibes.

## Policy boundary (the never-autoship list, verbatim)

From `MONITOR_RUNBOOK.md`:

- §3.1 math — gates, basis, APY, fees, deferral, exit triggers
- §4 active fields + defaults
- §7.1.1 schema beyond additive (no renames, no drops, no reshapes)
- §8.1 frozen `/api/diagnostics` JSON contract
- Venue gateways' order placement paths (`place_market_fok`, rollback)
- `docs/SYSTEM.md` spec sections (§0, §3, §4, §7.1.1, §8.1). Allowed:
  §16 append-only learnings, §18 closing existing rows.
- Credentials, env-var names, auth paths.

Note the careful scoping: §16 (learnings) and §18 (open gaps) are
explicitly allowed for autopilot because they're append-only and
operator-acknowledged. Everything else in the spec is policy.

## What the loop ships (representative sample)

From the bot's PR history:

- **#51** — fix v1.5 startup against legacy v1.3 DB + KuCoin passphrase
  env var. Anomaly-driven: cron flagged `endpoint_returned_error`, a
  prior Claude session diagnosed it, the loop shipped the migration fix.
- **#49** — parity harness in-process mode + boot-time account-id
  assertion. Closed an `UPGRADE_BACKLOG.md` hint.
- **#43** — remove `max_hold_hours`; add `basis_dislocation_exit_bps`.
  Required explicit operator decision (touched §4 active fields).

## Cadence

3-hour `/loop`. At a typical cadence the loop does ~5–10 monitor passes
per day, ships 0–2 PRs depending on the backlog. Most passes are
heartbeat acknowledgements: "no anomalies, no work surface yielded a
candidate, see you in 3h".

## What the operator does

- Reviews the PR stream (typically once a day).
- Adds hints to `UPGRADE_BACKLOG.md` when there's something specific to
  prioritise.
- Updates the SSOT directly when policy needs to change. The loop
  honours the new boundary on the next pass.
- Slams the brakes by leaving a "no" comment on a recent claude/* PR
  or by reverting one — triggers the 3-pass cooldown.

That's the entire human workload. The loop handles everything else.
