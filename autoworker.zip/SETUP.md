# Setup

The fast path is to use [`BOOTSTRAP_PROMPT.md`](BOOTSTRAP_PROMPT.md) — paste
it into a Claude Code session in your target repo and answer ~5 questions.
This file documents the manual install for operators who want to see every
step.

## What gets installed

In your target repo:

- `MONITOR_RUNBOOK.md` (root) — the operating procedure
- `UPGRADE_BACKLOG.md` (root) — operator hint box
- `CLAUDE.md` (root) — operator preferences (merged or created)
- `.github/workflows/diagnostics.yml` — cron, every 3h by default
- `.github/scripts/diagnostics_post.py` — cron's tracker updater
- A persistent GitHub issue: `[bot-diagnostics] Tracker`

Nothing else. The pattern doesn't touch your application code.

## Manual install

```
# 1. Clone this template repo somewhere
git clone https://github.com/mbansia/AutoWorker.git /tmp/cma

# 2. In your target repo
cd <your-target-repo>

# 3. Copy templates with parameter substitution
PROJECT_NAME="MyService"
REPO_SLUG="myorg/myrepo"
SSOT_PATH="docs/SPEC.md"
DIAGNOSTICS_ENDPOINT="/api/diagnostics"
CRON_CADENCE='0 */3 * * *'
TRACKER_ISSUE_NUMBER="0"   # filled in after step 5

substitute() {
  sed \
    -e "s|{{PROJECT_NAME}}|${PROJECT_NAME}|g" \
    -e "s|{{REPO_SLUG}}|${REPO_SLUG}|g" \
    -e "s|{{SSOT_PATH}}|${SSOT_PATH}|g" \
    -e "s|{{DIAGNOSTICS_ENDPOINT}}|${DIAGNOSTICS_ENDPOINT}|g" \
    -e "s|{{CRON_CADENCE}}|${CRON_CADENCE}|g" \
    -e "s|{{TRACKER_ISSUE_NUMBER}}|${TRACKER_ISSUE_NUMBER}|g"
}

substitute < /tmp/cma/templates/MONITOR_RUNBOOK.md  > MONITOR_RUNBOOK.md
substitute < /tmp/cma/templates/UPGRADE_BACKLOG.md  > UPGRADE_BACKLOG.md
substitute < /tmp/cma/templates/CLAUDE.md.snippet   >> CLAUDE.md      # append
mkdir -p .github/workflows .github/scripts
substitute < /tmp/cma/templates/diagnostics.yml     > .github/workflows/diagnostics.yml
cp /tmp/cma/templates/diagnostics_post.py             .github/scripts/diagnostics_post.py

# 4. Edit MONITOR_RUNBOOK.md's "NEVER AUTOSHIP — project policy hard line"
#    section. Fill it with YOUR project's never-touch list. This is the
#    safety boundary; do not skip it.

# 5. Create the tracker issue
gh issue create \
  --title "[bot-diagnostics] Tracker" \
  --label "bot-diagnostics" \
  --body "Initial — awaiting first cron run."
# Note the issue number it returns; substitute TRACKER_ISSUE_NUMBER and
# re-run the substitute step on MONITOR_RUNBOOK.md + CLAUDE.md.

# 6. Set GitHub secrets
gh secret set BOT_URL --body "https://your-service.example.com"
gh secret set DIAGNOSTICS_TOKEN --body "<your-token>"

# 7. Commit + PR
git checkout -b install-monitor-autopilot
git add MONITOR_RUNBOOK.md UPGRADE_BACKLOG.md CLAUDE.md .github/
git commit -m "Install Claude Monitor + Autopilot pattern"
git push -u origin install-monitor-autopilot
gh pr create --fill
```

After merging, kick off the loop in a Claude Code session:

```
/loop 3h <paste contents of LOOP_PROMPT.md, with parameters substituted>
```

## Prerequisites your project needs

- **A spec doc.** The pattern reads it to classify anomalies and decide
  policy. Minimal skeleton: vocabulary section, system SOP, anomaly rules,
  response policy, learnings section. AutoTrader_Codex's
  [`docs/SYSTEM.md`](https://github.com/mbansia/autotrader_codex/blob/main/docs/SYSTEM.md)
  is a reference.
- **A diagnostics endpoint (optional).** Cron needs an HTTP surface to
  poll. If your project has nothing, skip the cron and drive the loop
  via `/loop` only — manual / SDK-driven invocation works fine.
- **GitHub Actions enabled.** The cron lives there.
- **Two repo secrets.** `BOT_URL` + `DIAGNOSTICS_TOKEN`.
- **A clearly-defined policy boundary.** What MUST autopilot never touch?
  Money-handling? Schema? Public contracts? Write it down in the runbook
  before activating the loop.

## What happens after install

- Cron fires `{{CRON_CADENCE}}`. Hits `{{DIAGNOSTICS_ENDPOINT}}`. Updates
  the tracker issue body with the latest snapshot, posts a comment.
- A `/loop` session (or external cron) wakes up, reads the runbook + SSOT
  + tracker, decides per the action matrix.
- New anomalies get triaged. Safe-to-ship work gets PR'd + merged.
- Operator reviews the PR stream in their normal workflow.

## Uninstall

```
rm MONITOR_RUNBOOK.md UPGRADE_BACKLOG.md
rm .github/workflows/diagnostics.yml .github/scripts/diagnostics_post.py
# Remove the "Monitor + autopilot sessions" + "PR autonomy" + "SSOT"
# sections from CLAUDE.md (leave any other operator preferences).
gh issue close <tracker-issue-number>
gh secret delete BOT_URL
gh secret delete DIAGNOSTICS_TOKEN
```
